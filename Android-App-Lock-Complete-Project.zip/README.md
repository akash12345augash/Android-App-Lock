# Android App Lock Starter

A Kotlin + Jetpack Compose Android Studio starter project for an app-lock concept. It includes PIN-based locking, a basic pattern/PIN flow, biometric integration scaffolding, installed-app selection, an Accessibility-based monitoring prototype, and a visible camera activity prototype.

## Build on GitHub Actions

1. Download and extract this ZIP.
2. Open your GitHub repository and choose **Add file → Upload files**.
3. Upload the **contents of the extracted folder** (not the ZIP itself) to the repository root. Keep `.github/workflows/android.yml` and the `app/` folder.
4. Commit the files.
5. Open **Actions** and run **Build App Lock APK**. Pushes to `main` or `master` also trigger a build.
6. When the workflow succeeds, download `app-debug-apk` from the run's **Artifacts** section and extract it to find the APK.

This workflow uses Gradle installed by GitHub Actions, so the Gradle Wrapper script (`gradlew`) is not required for this CI build. Android Studio can generate a wrapper if you want one for local builds.

## Project files

- `app/` — Android source and resources
- `build.gradle.kts` — plugin versions
- `settings.gradle.kts` — project settings
- `.github/workflows/android.yml` — GitHub Actions APK build

## Limitations

This is a starter/prototype, not a production-ready security product. Android restricts background app monitoring and camera access. The Accessibility service must be explicitly enabled by the user; camera capture should remain visible and permission-based. The launcher-icon hiding feature is not implemented. Test on real devices and complete security, lifecycle, and Android-version testing before release.
