package com.example.applock

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.content.Intent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/** Deliberately uses the visible system camera UI; Android does not permit covert background camera capture. */
class CameraCaptureActivity : ComponentActivity() {
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) openCamera() else finish() }
    private val camera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        Toast.makeText(this, if (result.resultCode == RESULT_OK) "Camera capture completed" else "No photo captured", Toast.LENGTH_SHORT).show()
        finish()
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera() else permission.launch(Manifest.permission.CAMERA) }
    private fun openCamera() { camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) }
}
