package com.example.applock

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom

object AppPrefs {
    private fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("app_lock_prefs", Context.MODE_PRIVATE)
    fun pinExists(c: Context) = prefs(c).contains("pin_hash")
    fun setPin(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(c).edit().putString("pin_salt", salt.toHex()).putString("pin_hash", hash(pin, salt)).apply()
    }
    fun verifyPin(c: Context, pin: String): Boolean {
        val p = prefs(c); val salt = p.getString("pin_salt", null)?.hexToBytes() ?: return false
        val expected = p.getString("pin_hash", null) ?: return false
        return MessageDigest.isEqual(expected.toByteArray(), hash(pin, salt).toByteArray())
    }
    private fun hash(value: String, salt: ByteArray) = MessageDigest.getInstance("SHA-256").digest(salt + value.toByteArray()).toHex()
    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    fun selected(c: Context): Set<String> = prefs(c).getStringSet("selected_apps", emptySet())?.toSet() ?: emptySet()
    fun setSelected(c: Context, values: Set<String>) { prefs(c).edit().putStringSet("selected_apps", values.toSet()).apply() }
    fun pattern(c: Context) = prefs(c).getString("pattern", "") ?: ""
    fun setPattern(c: Context, value: String) { prefs(c).edit().putString("pattern", value).apply() }
    fun failed(c: Context) = prefs(c).getInt("failed_attempts", 0)
    fun setFailed(c: Context, count: Int) { prefs(c).edit().putInt("failed_attempts", count).apply() }
    fun hideIcon(c: Context) = prefs(c).getBoolean("hide_icon", false)
    fun setHideIcon(c: Context, value: Boolean) { prefs(c).edit().putBoolean("hide_icon", value).apply() }
    fun isAuthorized(c: Context, packageName: String) = prefs(c).getString("authorized_package", "") == packageName
    fun authorize(c: Context, packageName: String) { prefs(c).edit().putString("authorized_package", packageName).apply() }
    fun clearAuthorization(c: Context) { prefs(c).edit().remove("authorized_package").apply() }
}
