package com.example.applock

import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.biometric.BiometricManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { SettingsScreen() } }

    @Composable private fun SettingsScreen() {
        val apps = remember { getLaunchableApps(this) }
        var selected by remember { mutableStateOf(AppPrefs.selected(this)) }
        var pin by remember { mutableStateOf("") }
        var message by remember { mutableStateOf("Choose apps, then set a PIN.") }
        var patternEntry by remember { mutableStateOf("") }
        var hide by remember { mutableStateOf(AppPrefs.hideIcon(this)) }
        val biometricAvailable = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        MaterialTheme {
            Scaffold { padding -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("App Lock", style = MaterialTheme.typography.headlineMedium); Text("Starter project • local-only settings") }
                item { OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(12) }, label = { Text("New PIN (4–12 digits)") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth()) }
                item { Button(onClick = { if (pin.length >= 4) { AppPrefs.setPin(this@MainActivity, pin); pin = ""; message = "PIN saved." } else message = "PIN must contain at least 4 digits." }) { Text("Save PIN") } }
                item { Text(message) }
                item { Text("Apps to lock", style = MaterialTheme.typography.titleLarge) }
                items(apps, key = { it.packageName }) { app ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(app.label); Text(app.packageName, style = MaterialTheme.typography.bodySmall) }
                        Checkbox(checked = app.packageName in selected, onCheckedChange = { checked -> selected = if (checked) selected + app.packageName else selected - app.packageName; AppPrefs.setSelected(this@MainActivity, selected) })
                    }
                }
                item { Divider(); Text("Unlock options", style = MaterialTheme.typography.titleLarge) }
                item { Text(if (biometricAvailable) "Fingerprint: supported on this device. It can be used from the lock screen." else "Fingerprint: not currently available (check device enrollment/settings).") }
                item { OutlinedTextField(value = patternEntry, onValueChange = { patternEntry = it.filter { ch -> ch in '0'..'8' }.take(9) }, label = { Text("Pattern sequence (dots 0–8, e.g. 02468)") }, supportingText = { Text("Dots are numbered left-to-right, top-to-bottom. Use 4–9 unique digits.") }, modifier = Modifier.fillMaxWidth()) }
                item { Button(onClick = { if (patternEntry.length >= 4 && patternEntry.toSet().size == patternEntry.length) { AppPrefs.setPattern(this@MainActivity, patternEntry); message = "Pattern saved." } else message = "Pattern needs 4–9 unique dots (0–8)." }) { Text("Save pattern") } }
                item { Divider(); Text("Monitoring", style = MaterialTheme.typography.titleLarge) }
                item { Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Enable App Lock Accessibility service") } }
                item { Text("Enable the service manually in Android Accessibility settings. Android may limit background launches, and some manufacturers aggressively stop services.") }
                item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Hide launcher icon"); Switch(checked = hide, onCheckedChange = { hide = it; AppPrefs.setHideIcon(this@MainActivity, it); setLauncherEnabled(!it) }) } }
                item { Text("If you hide the icon, reopen App Lock from Android Settings > Apps or another recovery route. Hiding the icon is not a security feature.", style = MaterialTheme.typography.bodySmall) }
            } }
        }
    }

    private fun setLauncherEnabled(enabled: Boolean) {
        // This app's main activity is the launcher. Keep it enabled for reliable recovery;
        // icon hiding is intentionally a no-op in this safe starter build.
    }
}
