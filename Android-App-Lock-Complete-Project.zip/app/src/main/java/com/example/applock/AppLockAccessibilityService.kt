package com.example.applock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.os.SystemClock

class AppLockAccessibilityService : AccessibilityService() {
    private var lastPackage = ""
    private var lastLaunchAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED)) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == this.packageName) return
        if (packageName != lastPackage) AppPrefs.clearAuthorization(this)
        lastPackage = packageName
        if (packageName !in AppPrefs.selected(this) || AppPrefs.isAuthorized(this, packageName)) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastLaunchAt < 1200) return
        lastLaunchAt = now
        startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("target_package", packageName))
    }
    override fun onInterrupt() = Unit
}
