package com.example.applock

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import java.util.concurrent.Executor

class LockActivity : FragmentActivity() {
    private lateinit var target: String
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); target = intent.getStringExtra("target_package") ?: ""; setContent { LockScreen() } }

    @Composable private fun LockScreen() {
        var pin by remember { mutableStateOf("") }
        var pattern by remember { mutableStateOf("") }
        var usePattern by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf("Unlock to continue") }
        MaterialTheme {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("App locked", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(12.dp)); Text("Enter your PIN or pattern")
                if (usePattern && AppPrefs.pattern(this@LockActivity).isNotEmpty()) {
                    Text("Tap dots in order (0–8)")
                    for (row in 0..2) Row(horizontalArrangement = Arrangement.Center) { for (col in 0..2) { val n = row * 3 + col; Button(onClick = { pattern += n.toString(); if (pattern.length > 9) pattern = pattern.takeLast(9) }, modifier = Modifier.padding(4.dp).size(58.dp), shape = CircleShape, contentPadding = PaddingValues(0.dp)) { Text(n.toString()) } } }
                    Button(onClick = { if (pattern == AppPrefs.pattern(this@LockActivity)) success() else failure { message = "Wrong pattern" }; pattern = "" }) { Text("Unlock with pattern") }
                } else {
                    OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(12) }, label = { Text("PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    Button(onClick = { if (AppPrefs.verifyPin(this@LockActivity, pin)) success() else failure { message = "Incorrect PIN" }; pin = "" }, modifier = Modifier.padding(top = 12.dp)) { Text("Unlock") }
                }
                TextButton(onClick = { usePattern = !usePattern; pattern = "" }) { Text(if (usePattern) "Use PIN" else "Use pattern") }
                TextButton(onClick = { showBiometric { success() } }) { Text("Use fingerprint") }
                Text(message, modifier = Modifier.padding(top = 12.dp))
            }
        }
    }

    private fun success() { AppPrefs.setFailed(this, 0); if (target.isNotBlank()) AppPrefs.authorize(this, target); finish() }
    private fun failure(showMessage: () -> Unit) {
        val attempts = AppPrefs.failed(this) + 1; AppPrefs.setFailed(this, attempts); showMessage()
        if (attempts >= 5) { startActivity(Intent(this, CameraCaptureActivity::class.java)); AppPrefs.setFailed(this, 0) }
    }
    private fun showBiometric(onSuccess: () -> Unit) {
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { }
            override fun onAuthenticationFailed() { }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle("Unlock app").setSubtitle("Verify your identity").setNegativeButtonText("Cancel").build()
        prompt.authenticate(info)
    }
}
