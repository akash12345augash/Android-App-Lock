# AppLockStarter — Kotlin Android project

A source project for an Android app-lock prototype, built with Kotlin, Jetpack Compose, AndroidX Biometric, and an explicitly user-enabled AccessibilityService.

## Features in this starter

- Set and verify a numeric PIN (stored as a salted SHA-256 verifier, not plaintext).
- Save a pattern as a sequence of unique 3×3 dot numbers (0–8) and enter it on the lock screen.
- Offer Android biometric authentication from the lock screen when strong biometrics are enrolled.
- List launcher apps and select which package names should trigger the lock screen.
- Provide an Accessibility settings shortcut; the user must enable the service manually.
- After five failed attempts, offer the system camera UI visibly (with permission). This is not covert capture and does not guarantee that a full-resolution image is saved by every camera app.
- GitHub Actions workflow to build a debug APK and upload it as an artifact.

## Build with GitHub Actions

1. Extract this ZIP.
2. Create a GitHub repository.
3. Upload the *contents* of the `AppLockStarter` folder, including `.github/workflows/android.yml` and the `app/` directory.
4. Open **Actions**. The workflow runs on push and can also be started with **Run workflow**.
5. Open the completed run and download the `app-debug-apk` artifact.

The workflow uses Java 17 and Gradle 8.9. To build locally, open the folder in Android Studio (recent stable version), install Android SDK 35, allow Gradle sync, and run `assembleDebug`.

## Important limitations

This is a prototype, not a system-level lock. Android does not provide ordinary apps with a universal API to prevent another app from opening. Accessibility monitoring must be enabled by the user, can be stopped by the OS/device vendor, and behavior varies across Android versions and manufacturers. Some protected/system apps cannot be reliably covered. Do not rely on this app to protect high-value data.

- Pattern entry is a sequence of dot taps rather than a continuous drag gesture.
- The "hide launcher icon" switch is intentionally a placeholder; it does not disable the launcher activity. Keeping a recovery path avoids locking the owner out.
- The camera step opens visible system camera UI; no silent/background photography is performed.
- PIN verification uses a salted SHA-256 digest for this demo. A production app should use Android Keystore-backed key material, attempt throttling, and security review. Pattern data is currently stored locally and should not be treated as strong protection.
- App selection and preferences are stored locally on the device.

## Permissions / setup

No Accessibility service is enabled automatically. Install the app, open it, then use **Enable App Lock Accessibility service** and explicitly turn it on in Android Settings. Grant camera permission only if you want to use the visible camera flow. Fingerprint use requires an enrolled strong biometric and a secure device lock screen.

## Repository structure

- `app/src/main/java/com/example/applock/MainActivity.kt` — setup screen and app picker
- `LockActivity.kt` — PIN, pattern, and biometric prompt
- `AppLockAccessibilityService.kt` — watches app/window transitions and requests the lock screen
- `AppPrefs.kt` — local preferences and PIN verifier
- `InstalledApps.kt` — discovers launchable apps
- `CameraCaptureActivity.kt` — visible system camera handoff after failed attempts
- `.github/workflows/android.yml` — GitHub Actions debug APK build

## License

MIT — see `LICENSE`.
